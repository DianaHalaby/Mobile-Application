package com.example.simpleride;

public class passengeravailable {

    String FirstName;
    String Meetingpoint;
    String From;
    String To;
    String Time;
    String PassengerToken;
    String PuserId;

    public passengeravailable(String puserId) {
        this.PuserId = puserId;
    }

    public String getPuserId() {
        return PuserId;
    }

    public void setPuserId(String puserId) {
        this.PuserId = puserId;
    }

    public String getPassengerToken() {
        return PassengerToken;
    }

    public void setPassengerToken(String passengerToken) {
        this.PassengerToken = passengerToken;
    }

    public passengeravailable(){
        //fade krmel el firestore  mnjib lma3lumet mn el myadapter
    }

    public passengeravailable(String firstName, String meetingpoint, String from, String to, String time,String passengerToken) {
        this.FirstName = firstName;
        this.Meetingpoint = meetingpoint;
        this.From = from;
        this.To = to;
        this.Time = time;
        this.PassengerToken=passengerToken;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        this.FirstName = firstName;
    }

    public String getMeetingpoint() {
        return Meetingpoint;
    }

    public void setMeetingpoint(String meetingpoint) {
        this.Meetingpoint = meetingpoint;
    }

    public String getFrom() {
        return From;
    }

    public void setFrom(String from) {
        this.From = from;
    }

    public String getTo() {
        return To;
    }

    public void setTo(String to) {
        this.To = to;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        this.Time = time;
    }
}
