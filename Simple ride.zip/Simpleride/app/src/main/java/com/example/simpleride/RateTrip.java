package com.example.simpleride;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class RateTrip extends AppCompatActivity {

    TextView idrate;
    EditText ratetrip,ratedriver;
    Button sendrates,tback;

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate_trip);

        idrate=findViewById(R.id.tvrate1);
        Intent c = getIntent();
        String tuserid1 = c.getStringExtra("tuserid1");
        idrate.setText(tuserid1);

        ratetrip=findViewById(R.id.etratetrip);
        ratedriver=findViewById(R.id.etratedriver);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        sendrates=findViewById(R.id.btnratetrip);
        tback=findViewById(R.id.btnback);

        sendrates.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ratetrip1 =ratetrip.getText().toString().trim();
                String ratedriver1=ratedriver.getText().toString().trim();
                String tname=idrate.getText().toString();

                DocumentReference documentReference29=fStore.collection("CommentsAsTrip").document(tname);
                Map<String,Object> CommentsAsTrip=new HashMap<>();
                CommentsAsTrip.put("CommentsTrip",ratetrip1);
                CommentsAsTrip.put("CommentsDriver",ratedriver1);
                documentReference29.set(CommentsAsTrip).addOnSuccessListener((OnSuccessListener) (aVoid) ->{
                    Toast. makeText(getApplicationContext(),"Rating !",Toast. LENGTH_SHORT).show();

                });
                if (TextUtils.isEmpty(ratetrip1)) {
                    ratetrip.setError("Please rate the trip");
                    return;
                }
                if (TextUtils.isEmpty(ratedriver1)) {
                    ratedriver.setError("Please rate the driver");
                    return;
                }
            }
        });
        tback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent g=new Intent(RateTrip.this,openapp.class);
                Toast.makeText(RateTrip.this,"Back to Main",Toast.LENGTH_SHORT).show();
                startActivity(g);
            }
        });

    }

}
