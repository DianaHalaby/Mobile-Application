package com.example.simpleride;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class Myadapter2 extends RecyclerView.Adapter<Myadapter2.MyViewHolderss> {
// 1- bs ktbt hayda lsater b3ml click 3le w create all method
// 4- hl2 b3be lm3lumet lbde yahaa

    Context context2;
    ArrayList<usersavailable> usersavailableArrayList;
    //5-rj3t 3mltln consturctor

    public Myadapter2(Context context2, ArrayList<usersavailable> usersavailableArrayList) {
        this.context2 = context2;
        this.usersavailableArrayList = usersavailableArrayList;
    }

    @NonNull
    @Override
    public Myadapter2.MyViewHolderss onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // 9- hon eltla ena ra7 tle2iya b aya page l2n haydee class wen ra7 tle2iyaa b xmll
        View v= LayoutInflater.from(context2).inflate(R.layout.activity_usersavailable,parent,false);
        return new MyViewHolderss(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Myadapter2.MyViewHolderss holder, int position) {
        //10- create object of useravailable class mnjibun mn larray class hsb lposition
        usersavailable usersavailable1=usersavailableArrayList.get(position);
        holder.ufn.setText(usersavailable1.FirstName);
        holder.uln.setText(usersavailable1.LastName);
        holder.uabout.setText(usersavailable1.Aboutyou);
        holder.uage.setText(usersavailable1.Age);
        holder.ucar.setText(usersavailable1.Car);
        holder.unat.setText(usersavailable1.Nationality);
        holder.cd.setText(usersavailable1.CommentasDriver);
        holder.ct.setText(usersavailable1.CommentasTrip);
        holder.cp.setText(usersavailable1.CommentasPassenger);
    }

    @Override
    public int getItemCount() {
        //6-eltln lcount kif bda tkunn
        return usersavailableArrayList.size();
    }
    // 2- b3ml hayde
    public static class MyViewHolderss extends RecyclerView.ViewHolder{
        //7-hon 3raft kl lesass lbde yaha tbaynn
        TextView ufn,uln,uage,unat,ucar,uabout,cd,ct,cp;
        // 3- bf2s 3laya w b3ml create constructor
        public MyViewHolderss(@NonNull View itemView) {
            super(itemView);
            //8-
            ufn=itemView.findViewById(R.id.ufn);
            uln=itemView.findViewById(R.id.uln);
            uage=itemView.findViewById(R.id.uage);
            unat=itemView.findViewById(R.id.unat);
            ucar=itemView.findViewById(R.id.ucar);
            uabout=itemView.findViewById(R.id.uabout);
            cd=itemView.findViewById(R.id.ucd);
            ct=itemView.findViewById(R.id.uct);
            cp=itemView.findViewById(R.id.ucp);
        }
    }
}

