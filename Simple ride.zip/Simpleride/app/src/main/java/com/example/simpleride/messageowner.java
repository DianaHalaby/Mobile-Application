package com.example.simpleride;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.messaging.FirebaseMessaging;

public class messageowner extends AppCompatActivity {

    EditText titleowner,bodyowner;
    Button sendowner,ratetrip;
    TextView tokenowner,tvtuserid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messageowner);

        titleowner=findViewById(R.id.ettitleowner2);
        bodyowner=findViewById(R.id.etbodyowner);
        tokenowner=findViewById(R.id.tvttokenowner);
        sendowner=findViewById(R.id.btsendowner);
        tvtuserid=findViewById(R.id.tvtuserid);

        FirebaseMessaging.getInstance().subscribeToTopic("all");
        Intent t = getIntent();
        String ttoken = t.getStringExtra("totokenkey");
        tokenowner.setText(ttoken);
        String tuserid=t.getStringExtra("tuserid");
        tvtuserid.setText(tuserid);

        ratetrip=findViewById(R.id.btratetrip);

        sendowner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!titleowner.getText().toString().isEmpty() && !bodyowner.getText().toString().isEmpty() && !tokenowner.getText().toString().isEmpty()) {
                    FcmNotificationSender1 fcmNotificationsSender1 = new FcmNotificationSender1(tokenowner.getText().toString(), titleowner.getText().toString(), bodyowner.getText().toString(), getApplicationContext(), messageowner.this);
                    fcmNotificationsSender1.SendNotifications();
                    Toast.makeText(messageowner.this, "Sending Message", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(messageowner.this, "Please Fill al details!!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        ratetrip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent c= new Intent(messageowner.this,RateTrip.class);

                String tuserid1=tvtuserid.getText().toString();
                c.putExtra("tuserid1",tuserid1);

                startActivity(c);
            }
        });
    }
}