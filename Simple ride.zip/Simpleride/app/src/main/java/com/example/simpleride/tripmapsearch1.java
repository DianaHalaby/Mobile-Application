package com.example.simpleride;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.messaging.FirebaseMessaging;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class tripmapsearch1 extends AppCompatActivity implements OnMapReadyCallback {

    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COURSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;

    EditText fromss, toss,mp,namep,time,passengertoken,pdate,puserid;
    Button search;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String userID;

    private Boolean mLocationPermissionsGranted = false;
    private GoogleMap mMap;
    Myadapter1 myadapter1;
    ArrayList<tripsavailable> tripsavailableArrayList;
    RecyclerView tarc;
    ProgressDialog progressDialog1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tripmapsearch1);

        puserid=findViewById(R.id.etpuserid);
        fromss = findViewById(R.id.etfromsearch);
        toss = findViewById(R.id.ettosearch);
        search = findViewById(R.id.startsearch);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        userID = fAuth.getCurrentUser().getUid();

        passengertoken=findViewById(R.id.etpassengertoken);
        mp=findViewById(R.id.etmp2);
        namep=findViewById(R.id.etname1);
        time=findViewById(R.id.ettime1);
        tarc=findViewById(R.id.triprc);
        pdate=findViewById(R.id.etpdate);

        tarc.setHasFixedSize(true);
        tarc.setLayoutManager(new LinearLayoutManager(tripmapsearch1.this));
        tripsavailableArrayList=new ArrayList<tripsavailable>();
        myadapter1=new Myadapter1(tripmapsearch1.this,tripsavailableArrayList);

        progressDialog1=new ProgressDialog(this);
        progressDialog1.setCancelable(true);
        progressDialog1.setMessage("Fetching Data");
        progressDialog1.show();
        tarc.setAdapter(myadapter1);
        puserid.setText(userID);

        EventChangeListener();
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(new OnCompleteListener<String>() {
            @Override
            public void onComplete(@NonNull Task<String> task) {
                String token=task.getResult();
                passengertoken.setText(token);

            }
        });

        getLocationPermission1();
        DocumentReference documentReference5 = fStore.collection("Tripsearch").document(userID);
        documentReference5.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {

                fromss.setText(documentSnapshot.getString("From"));
                toss.setText(documentSnapshot.getString("To"));
                mp.setText(documentSnapshot.getString("Meeting point"));
                time.setText(documentSnapshot.getString("Time"));
                pdate.setText(documentSnapshot.getString("Date"));

            }
        });
        DocumentReference documentReference6 = fStore.collection("users").document(userID);
        documentReference6.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {

                namep.setText(documentSnapshot.getString("FirstName"));

            }
        });
    }

    private void EventChangeListener() {
        fStore.collection("tripsavailable").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Toast.makeText(tripmapsearch1.this, "error", Toast.LENGTH_SHORT).show();
                    if (progressDialog1.isShowing())
                        progressDialog1.dismiss();
                }
                for (DocumentChange dc : value.getDocumentChanges()) {
                    if (dc.getType() == DocumentChange.Type.ADDED) {
                        tripsavailableArrayList.add(dc.getDocument().toObject(tripsavailable.class));
                    }
                    myadapter1.notifyDataSetChanged();
                    if (progressDialog1.isShowing())
                        progressDialog1.dismiss();
                }
            }});
    }

    private void init() {

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String puserid1=puserid.getText().toString();

                String pdate1=pdate.getText().toString();
                String fromss1=fromss.getText().toString();
                String toss1=toss.getText().toString();
                String mp1=mp.getText().toString();
                String namep1=namep.getText().toString();
                String time1=time.getText().toString();
                String passengertoken1=passengertoken.getText().toString();
                userID=fAuth.getCurrentUser().getUid();
                DocumentReference documentReference5=fStore.collection("passengeravailable").document(userID);
                DocumentReference documentReference6=fStore.collection("passengeravailable").document(userID);
                Map<String,Object> passengeravailable=new HashMap<>();
                passengeravailable.put("PuserId",puserid1);
                passengeravailable.put("Date",pdate1);
                passengeravailable.put("Time",time1);
                passengeravailable.put("FirstName",namep1);
                passengeravailable.put("From",fromss1);
                passengeravailable.put("To",toss1);
                passengeravailable.put("Meetingpoint",mp1);
                passengeravailable.put("PassengerToken",passengertoken1);

                documentReference5.set(passengeravailable).addOnSuccessListener((OnSuccessListener) (aVoid) ->{
                    Toast. makeText(getApplicationContext(),"Searching for A trip",Toast. LENGTH_SHORT).show();

                });
                documentReference6.set(passengeravailable).addOnSuccessListener((OnSuccessListener) (aVoid) ->{});
                geoLocate();

            }
        });
    }

    private void geoLocate() {
        String searchString4 = fromss.getText().toString();
        String searchStrin5 = toss.getText().toString();

        Geocoder geocoder = new Geocoder(tripmapsearch1.this);
        List<Address> list4 = new ArrayList<>();
        List<Address> list5 = new ArrayList<>();

        try {
            list4 = geocoder.getFromLocationName(searchString4, 1);
            list5 = geocoder.getFromLocationName(searchStrin5, 1);

        } catch (IOException e) {
        }

        Address address4 = list4.get(0);
        LatLng adress4 = new LatLng(address4.getLatitude(), address4.getLongitude());
        MarkerOptions options4 = new MarkerOptions()
                .title("From").position(adress4);

        mMap.addMarker(options4);

        Address address5 = list5.get(0);
        LatLng adress5 = new LatLng(address5.getLatitude(), address5.getLongitude());
        MarkerOptions options5 = new MarkerOptions().title("To")
                .position(adress5);

        mMap.addMarker(options5);

        mMap.addPolyline(new PolylineOptions().add(adress4, adress5).width(5).color(Color.RED));
    }

    private void initMap() {
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map1);

        mapFragment.getMapAsync(tripmapsearch1.this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        LatLng lebanon = new LatLng(33.888630, 35.495480);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(lebanon, 8f));

        if (mLocationPermissionsGranted) {


            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            mMap.setMyLocationEnabled(true);
            mMap.getUiSettings().setMyLocationButtonEnabled(true);
            mMap.getUiSettings().setZoomGesturesEnabled(true);
            mMap.getUiSettings().setScrollGesturesEnabled(true);
            mMap.getUiSettings().setZoomControlsEnabled(true);

            init();
        }
    }
    private void getLocationPermission1(){
        String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION};

        if(ContextCompat.checkSelfPermission(this.getApplicationContext(),
                FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            if(ContextCompat.checkSelfPermission(this.getApplicationContext(),
                    COURSE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                mLocationPermissionsGranted = true;
                initMap();
            }else{
                ActivityCompat.requestPermissions(this,
                        permissions,
                        LOCATION_PERMISSION_REQUEST_CODE);
            }
        }else{
            ActivityCompat.requestPermissions(this,
                    permissions,
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        //  Log.d(TAG, "onRequestPermissionsResult: called.");
        mLocationPermissionsGranted = false;

        switch (requestCode) {
            case LOCATION_PERMISSION_REQUEST_CODE: {
                if (grantResults.length > 0) {
                    for (int i = 0; i < grantResults.length; i++) {
                        if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                            mLocationPermissionsGranted = false;
                            return;
                        }
                    }
                    mLocationPermissionsGranted = true;
                    initMap();
                }
            }
        }
    }
}
