package com.example.simpleride;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.messaging.FirebaseMessaging;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class tripmap1 extends AppCompatActivity implements OnMapReadyCallback {

    @Override
    public void onMapReady(GoogleMap googleMap) {

        Toast.makeText(this, "Map is Ready", Toast.LENGTH_SHORT).show();

        mMap = googleMap;
        LatLng lebanon = new LatLng(33.888630, 35.495480);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(lebanon, 8f));

        if (mLocationPermissionsGranted) {

            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            mMap.setMyLocationEnabled(true);
            mMap.getUiSettings().setMyLocationButtonEnabled(true);
            mMap.getUiSettings().setZoomGesturesEnabled(true);
            mMap.getUiSettings().setScrollGesturesEnabled(true);
            mMap.getUiSettings().setZoomControlsEnabled(true);
            init();
        }
    }

    private static final String TAG = "Trip Map";
    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COURSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final float DEFAULT_ZOOM = 10f;

    private EditText from,to,stop1,stop2;
    TextView fn,cart,colort,triptime,tripownertoken,tdate,tuserid;
    private Boolean mLocationPermissionsGranted = false;
    private GoogleMap mMap;

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String userID ;
    Button bt;
    Myadapter myadapter;
    ArrayList<passengeravailable> passengeravailableArrayList;
    RecyclerView recyclerView;
    ProgressDialog progressDialog;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tripmap1);
        tripownertoken=findViewById(R.id.tripownertoken);
        from =findViewById(R.id.etfromtrip);
        to=findViewById(R.id.ettotrip);
        stop1=findViewById(R.id.etstop1trip);
        stop2=findViewById(R.id.etstop2trip);
        triptime=findViewById(R.id.tvtriptime);
        fn=findViewById(R.id.tvtripfn);
        cart=findViewById(R.id.tvtripcar);
        colort=findViewById(R.id.tvtripcolor);
        tdate=findViewById(R.id.ettdate);
        tuserid=findViewById(R.id.tuserid);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        userID = fAuth.getCurrentUser().getUid();

        recyclerView=findViewById(R.id.rc1);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        passengeravailableArrayList=new ArrayList<passengeravailable>();
        myadapter=new Myadapter(tripmap1.this,passengeravailableArrayList);
        bt=findViewById(R.id.startsearch);
        progressDialog=new ProgressDialog(this);
        progressDialog.setCancelable(true);
        progressDialog.setMessage("Fetching Data");
        progressDialog.show();
        recyclerView.setAdapter(myadapter);
        tuserid.setText(userID);

        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(new OnCompleteListener<String>() {
            @Override
            public void onComplete(@NonNull Task<String> task) {
                String token=task.getResult();
                tripownertoken.setText(token);

            }
        });

        getLocationPermission();
        EventChangeListener();
        DocumentReference documentReference4=fStore.collection("Tripscreatedinfo").document(userID);
        documentReference4.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {

                from.setText(documentSnapshot.getString("From"));
                to.setText(documentSnapshot.getString("To"));
                stop1.setText(documentSnapshot.getString("FirstStop"));
                stop2.setText(documentSnapshot.getString("SecondStop"));
                triptime.setText(documentSnapshot.getString("Time"));
                tdate.setText(documentSnapshot.getString("Date"));
            }
        });
        DocumentReference documentReference10=fStore.collection("users").document(userID);
        documentReference10.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {

                cart.setText(documentSnapshot.getString("Car"));
                fn.setText(documentSnapshot.getString("FirstName"));

            }
        });  DocumentReference documentReference11=fStore.collection("Cars").document(userID);
        documentReference11.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {

                colort.setText(documentSnapshot.getString("Color"));

            }
        });

    }

    private void EventChangeListener() {
        fStore.collection("passengeravailable").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Toast.makeText(tripmap1.this, "error", Toast.LENGTH_SHORT).show();
                    if (progressDialog.isShowing())
                        progressDialog.dismiss();
                }
                for (DocumentChange dc : value.getDocumentChanges()) {
                    if (dc.getType() == DocumentChange.Type.ADDED) {
                        passengeravailableArrayList.add(dc.getDocument().toObject(passengeravailable.class));
                    }
                    myadapter.notifyDataSetChanged();
                    if (progressDialog.isShowing())
                        progressDialog.dismiss();
                }
            }});
    }


    private void init(){
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tuserid1=tuserid.getText().toString();
                String tdate1=tdate.getText().toString();
                String triptimet=triptime.getText().toString();
                String fromt=from.getText().toString();
                String tost=to.getText().toString();
                String stop1t=stop1.getText().toString();
                String stop2t=stop2.getText().toString();
                String fnt=fn.getText().toString();
                String cart1=cart.getText().toString();
                String colort1=colort.getText().toString();
                String tripownertoken1=tripownertoken.getText().toString();
                userID=fAuth.getCurrentUser().getUid();

                DocumentReference documentReference4=fStore.collection("tripsavailable").document(userID);
                DocumentReference documentReference10=fStore.collection("tripsavailable").document(userID);
                DocumentReference documentReference11=fStore.collection("tripsavailable").document(userID);
                Map<String,Object> tripsavailable=new HashMap<>();
                tripsavailable.put("TUserId",tuserid1);
                tripsavailable.put("Date",tdate1);
                tripsavailable.put("FirstName",fnt);
                tripsavailable.put("From",fromt);
                tripsavailable.put("To",tost);
                tripsavailable.put("FirstStop",stop1t);
                tripsavailable.put("SecondStop",stop2t);
                tripsavailable.put("CarType",cart1);
                tripsavailable.put("CarColor",colort1);
                tripsavailable.put("Time",triptimet);
                tripsavailable.put("TripOwnerToken",tripownertoken1);

                documentReference4.set(tripsavailable).addOnSuccessListener((OnSuccessListener) (aVoid) ->{
                    Toast. makeText(getApplicationContext(),"Creating A trip",Toast. LENGTH_SHORT).show();
                });
                documentReference10.set(tripsavailable).addOnSuccessListener((OnSuccessListener) (aVoid) ->{});
                documentReference11.set(tripsavailable).addOnSuccessListener((OnSuccessListener) (aVoid) ->{});
                geoLocate();
            }
        });
    }
    private void geoLocate(){
        Log.d(TAG, "geoLocate: geolocating");
        String searchString = from.getText().toString();
        String searchStrin1=to.getText().toString();
        String searchStrin2=stop1.getText().toString();
        String searchStrin3=stop2.getText().toString();

        Geocoder geocoder = new Geocoder(tripmap1.this);
        List<Address> list = new ArrayList<>();
        List<Address> list1 = new ArrayList<>();
        List<Address> list2 = new ArrayList<>();
        List<Address> list3 = new ArrayList<>();
        try{
            list = geocoder.getFromLocationName(searchString, 1);
            list1=geocoder.getFromLocationName(searchStrin1,1);
            list2=geocoder.getFromLocationName(searchStrin2,1);
            list3=geocoder.getFromLocationName(searchStrin3,1);
        }catch (IOException e){
            Log.e(TAG, "geoLocate: IOException: " + e.getMessage() );
        }
        Address address = list.get(0);
        LatLng adress =new LatLng(address .getLatitude(),address .getLongitude());
        MarkerOptions options   = new MarkerOptions().position(adress ).title("From");
        mMap.addMarker(options );

        Address address1 = list1.get(0);
        LatLng adress1=new LatLng(address1.getLatitude(),address1.getLongitude());
        MarkerOptions options1  = new MarkerOptions().title("To").position(adress1);
        mMap.addMarker(options1);

        Address address2 = list2.get(0);
        LatLng adress2=new LatLng(address2.getLatitude(),address2.getLongitude());
        MarkerOptions options2 = new MarkerOptions().title("First Stop").position(adress2);
        mMap.addMarker(options2);

        Address address3 = list3.get(0);
        LatLng adress3=new LatLng(address3.getLatitude(),address3.getLongitude());
        MarkerOptions options3  = new MarkerOptions().title("Second Stop").position(adress3);
        mMap.addMarker(options3);

        mMap.addPolyline(new PolylineOptions().add(adress,adress2,adress3,adress1).width(5).color(Color.RED));
    }
    private void initMap(){
        Log.d(TAG, "initMap: initializing map");
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map1);
        mapFragment.getMapAsync(tripmap1.this);
    }
    private void getLocationPermission(){
        Log.d(TAG, "getLocationPermission: getting location permissions");
        String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
        if(ContextCompat.checkSelfPermission(this.getApplicationContext(), FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            if(ContextCompat.checkSelfPermission(this.getApplicationContext(), COURSE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                mLocationPermissionsGranted = true;
                initMap();
            }else{
                ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);
            }
        }else{
            ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.d(TAG, "onRequestPermissionsResult: called.");
        mLocationPermissionsGranted = false;
        switch (requestCode) {
            case LOCATION_PERMISSION_REQUEST_CODE: {
                if (grantResults.length > 0) {
                    for (int i = 0; i < grantResults.length; i++) {
                        if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                            mLocationPermissionsGranted = false;
                            Log.d(TAG, "onRequestPermissionsResult: permission failed");
                            return;
                        }
                    }
                    Log.d(TAG, "onRequestPermissionsResult: permission granted");
                    mLocationPermissionsGranted = true;
                    initMap();
                }
            }
        }
    }
}