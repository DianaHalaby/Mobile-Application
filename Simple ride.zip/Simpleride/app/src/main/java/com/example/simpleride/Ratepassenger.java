package com.example.simpleride;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Ratepassenger extends AppCompatActivity {
    EditText rate;
    String name;
    TextView useridr1;
    Button submitl,back;

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ratepassenger);

        rate=findViewById(R.id.etrate);
        submitl=findViewById(R.id.btsubmit);
        useridr1=findViewById(R.id.useridr);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        back=findViewById(R.id.btback);

        Intent u = getIntent();
        String pidr=u.getStringExtra("pidrkey");
        useridr1.setText(pidr);
        name=useridr1.getText().toString();

        submitl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String rate1 =rate.getText().toString().trim();
                name=useridr1.getText().toString();

                DocumentReference documentReference22=fStore.collection("CommentsAsPassenger").document(name);
                Map<String,Object> CommentsAsPassenger=new HashMap<>();
                CommentsAsPassenger.put("Comments",rate1);

                documentReference22.set(CommentsAsPassenger).addOnSuccessListener((OnSuccessListener) (aVoid) ->{
                    Toast. makeText(getApplicationContext(),"Rating Passenger!",Toast. LENGTH_SHORT).show();

                });
                if (TextUtils.isEmpty(rate1)) {
                    rate.setError("Please Drop a comment!");
                    return;
                }
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent f=new Intent(Ratepassenger.this,openapp.class);
                Toast.makeText(Ratepassenger.this,"Back to Main",Toast.LENGTH_SHORT).show();
                startActivity(f);
            }
        });
    }
}