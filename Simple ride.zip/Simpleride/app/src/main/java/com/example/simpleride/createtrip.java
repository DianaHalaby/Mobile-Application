package com.example.simpleride;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import android.os.Bundle;
import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;

import android.os.Bundle;

import android.view.Menu;
import android.view.View;

import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import javax.annotation.Nullable;

public class createtrip extends AppCompatActivity {

    private DatePicker datePickert;
    private Calendar calendart;
    private TextView dateViewt;
    private int yeart, montht, dayt;

    /////////////
    EditText from, to, spot, fstop, sstop;
    Button create, time ;
    TextView date;


    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String userID;

    int hour, minute;

    DatePickerDialog.OnDateSetListener setListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createtrip);

        dateViewt = (TextView) findViewById(R.id.etdate);
        calendart = Calendar.getInstance();
        yeart = calendart.get(Calendar.YEAR);

        montht = calendart.get(Calendar.MONTH);
        dayt = calendart.get(Calendar.DAY_OF_MONTH);
        showDate(yeart, montht+1, dayt);

        ////////////


        fstop = findViewById(R.id.etfirststop);
        sstop = findViewById(R.id.etsecondstop);
        from = findViewById(R.id.etfrom);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        to = findViewById(R.id.etto);

        spot = findViewById(R.id.etspots);
        create = findViewById(R.id.btcreatetrip);
        date = findViewById(R.id.etdate);

        //lcalender mawjudi bl android bs ana 3m 3aytla hon
        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);
        time = findViewById(R.id.bttime);





//b3ml step l places la kel ledit textt
        //ana zdt library lal sapces bl gradle w bktb hl2 b2lba lapi key
        Places.initialize(getApplicationContext(), "AIzaSyD4S5nFUZLl4T-qQUPOzRERpY_Bf2r2ueg");
        //set edit text non focusable
        from.setFocusable(true);
        from.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //initialize place  field List then i should create intent then start activity for result
                List<Place.Field> fieldList = Arrays.asList(Place.Field.ADDRESS, Place.Field.LAT_LNG, Place.Field.NAME);
                Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fieldList).build(createtrip.this);
                startActivityForResult(intent, 100);
            }

        });
        to.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Place.Field> fieldList = Arrays.asList(Place.Field.ADDRESS, Place.Field.LAT_LNG, Place.Field.NAME);
                Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fieldList).build(createtrip.this);
                startActivityForResult(intent, 200);
            }

        });
        fstop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Place.Field> fieldList = Arrays.asList(Place.Field.ADDRESS,Place.Field.LAT_LNG, Place.Field.NAME);
                Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fieldList).build(createtrip.this);
                startActivityForResult(intent, 300);
            }

        });
        sstop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Place.Field> fieldList = Arrays.asList(Place.Field.ADDRESS, Place.Field.LAT_LNG, Place.Field.NAME);
                Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fieldList).build(createtrip.this);
                startActivityForResult(intent, 400);
            }

        });

/*
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(createtrip.this, android.R.style.Theme_Holo_Dialog_MinWidth, setListener, year, month, day);
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();
            }
        });
        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                String Date = day + "/" + month + "/" + year;
                date.setText(Date);
            }
        };
        */
    }


    // mn3mla hayde lal places krmel nt2kd iza sa77 by3tuna address
    protected void onActivityResult(int requestCode, int resultCode,
                                    @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100 && resultCode == RESULT_OK) {
            Place place = Autocomplete.getPlaceFromIntent(data);
            from.setText(place.getAddress());
        }
        if (requestCode == 200 && resultCode == RESULT_OK) {
            Place place1 = Autocomplete.getPlaceFromIntent(data);
            to.setText(place1.getAddress());

        }
        if (requestCode == 300 && resultCode == RESULT_OK) {
            Place place2 = Autocomplete.getPlaceFromIntent(data);
            fstop.setText(place2.getAddress());
        }
        if (requestCode == 400 && resultCode == RESULT_OK) {
            Place place3 = Autocomplete.getPlaceFromIntent(data);
            sstop.setText(place3.getAddress());
        }
    }

    public void popTimePicker(View view) {
        TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                hour = selectedHour;
                minute = selectedMinute;
                time.setText(String.format(Locale.getDefault(), "%02d:%02d", hour, minute));
            }
        };
        TimePickerDialog timePickerDialog = new TimePickerDialog(this, onTimeSetListener, hour, minute, true);
        timePickerDialog.show();
    }

    public void onclick(View view) {

        String from1 = from.getText().toString().trim();
        String to1 = to.getText().toString().trim();
        String spots1 = spot.getText().toString().trim();
        String date1 = date.getText().toString().trim();
        String time1 = time.getText().toString().trim();
        String FirstStop1 = fstop.getText().toString().trim();
        String SecondStop1 = sstop.getText().toString().trim();

        if (TextUtils.isEmpty(from1)) {
            from.setError("From is Required");
            return;
        }
        if (TextUtils.isEmpty(to1)) {
            to.setError("To is Required");
            return;
        }

        if (TextUtils.isEmpty(spots1)) {
            spot.setError("Spot is Required");
            return;
        }
        if (TextUtils.isEmpty(date1)) {
            date.setError("Date is Required");
            return;
        }
        if (TextUtils.isEmpty(time1)) {
            time.setError("Email is Required");
            return;
        }
        if (TextUtils.isEmpty(FirstStop1)) {
            fstop.setError("First stop is required to define your track!");
            return;
        }
        if (TextUtils.isEmpty(SecondStop1)) {
            sstop.setError("Second stop is required to define your track!");
            return;
        }

        Toast.makeText(createtrip.this, "Creating Trip Info", Toast.LENGTH_SHORT).show();

        userID = fAuth.getCurrentUser().getUid();

        DocumentReference documentReference = fStore.collection("Tripscreatedinfo").document(userID);
        Map<String, Object> Tripscreatedinfo = new HashMap<>();
        Tripscreatedinfo.put("From", from1);
        Tripscreatedinfo.put("To", to1);
        Tripscreatedinfo.put("Spots", spots1);
        Tripscreatedinfo.put("Date", date1);
        Tripscreatedinfo.put("Time", time1);
        Tripscreatedinfo.put("FirstStop", FirstStop1);
        Tripscreatedinfo.put("SecondStop", SecondStop1);
        documentReference.set(Tripscreatedinfo).addOnSuccessListener((OnSuccessListener) (aVoid) -> {
        });

        Intent i = new Intent(createtrip.this, tripmap1.class);
        startActivity(i);
    }
    /////////////////////


    @SuppressWarnings("deprecation")
    public void setDate(View view) {
        showDialog(999);
        Toast.makeText(getApplicationContext(), "ca",
                Toast.LENGTH_SHORT)
                .show();
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this,
                    myDateListener, yeart, montht, dayt);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new
            DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker arg0,
                                      int arg1, int arg2, int arg3) {
                    // TODO Auto-generated method stub
                    // arg1 = year
                    // arg2 = month
                    // arg3 = day
                    showDate(arg1, arg2+1, arg3);
                }
            };

    private void showDate(int year, int month, int day) {
        dateViewt.setText(new StringBuilder().append(day).append("/")
                .append(month).append("/").append(year));
    }

}
