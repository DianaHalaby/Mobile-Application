package com.example.simpleride;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;

public class userprofile extends AppCompatActivity {

    EditText firstname, lastname, age, aboutyou, model,color;
    Button save;
    TextView deactivate ;
    TextView nationality, gender, car,email,comment,commentdriver,commenttrip;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String userID;
    DocumentReference documentReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userprofile);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        nationality = findViewById(R.id.tvnationality);
        gender = findViewById(R.id.tvgender);
        car = findViewById(R.id.tvcar33);
        email = findViewById(R.id.tvpemail);
        firstname = findViewById(R.id.etpfirstname);
        lastname = findViewById(R.id.etplastname);
        age = findViewById(R.id.etpage);
        aboutyou = findViewById(R.id.etpaboutyou);
        save = findViewById(R.id.btpsave);
        model = findViewById(R.id.etpcarmodel);
        color = findViewById(R.id.etpcolor);
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        userID = fAuth.getCurrentUser().getUid();
        commentdriver=findViewById(R.id.tvpcommentdriver1);
        commenttrip=findViewById(R.id.tvpcommenttrip);
        comment=findViewById(R.id.tvpcomment);

        Toast.makeText(userprofile.this,"Press Save To Update Your Profile",Toast.LENGTH_SHORT).show();


        DocumentReference documentReference24=fStore.collection("CommentsAsPassenger").document(userID);
        documentReference24.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {

                comment.setText(documentSnapshot.getString("Comments"));


            }
        });
        DocumentReference documentReference26=fStore.collection("CommentsAsTrip").document(userID);
        documentReference26.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {

                commentdriver.setText(documentSnapshot.getString("CommentsDriver"));
                commenttrip.setText(documentSnapshot.getString("CommentsTrip"));


            }
        });

        DocumentReference documentReference1=fStore.collection("Cars").document(userID);
        documentReference1.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {

                color.setText(documentSnapshot.getString("Color"));
                model.setText(documentSnapshot.getString("Model"));

            }
        });

        DocumentReference documentReference = fStore.collection("users").document(userID);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                email.setText(documentSnapshot.getString("email"));
                firstname.setText(documentSnapshot.getString("FirstName"));
                lastname.setText(documentSnapshot.getString("LastName"));
                age.setText(documentSnapshot.getString("Age"));
                aboutyou.setText(documentSnapshot.getString("Aboutyou"));
                nationality.setText(documentSnapshot.getString("Nationality"));
                gender.setText(documentSnapshot.getString("Gender"));
                car.setText(documentSnapshot.getString("Car"));


                save.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String commentp = comment.getText().toString().trim();
                        String commentdriver1 = commentdriver.getText().toString().trim();
                        String commenttrip1 = commenttrip.getText().toString().trim();
                        String email1 = email.getText().toString().trim();
                        String firstname1 = firstname.getText().toString().trim();
                        String lastname1 = lastname.getText().toString().trim();
                        String age1 = age.getText().toString().trim();
                        String nationality1 = nationality.getText().toString().trim();
                        String gender1 = gender.getText().toString().trim();
                        String car1 = car.getText().toString().trim();
                        String aboutyou1 = aboutyou.getText().toString().trim();
                        String color1 = color.getText().toString().trim();
                        String model1 = model.getText().toString().trim();
                        userID = fAuth.getCurrentUser().getUid();

                        DocumentReference documentReference1 = fStore.collection("users").document(userID);
                        Map<String, Object> users = new HashMap<>();
                        users.put("email", email1);
                        users.put("FirstName", firstname1);
                        users.put("LastName", lastname1);
                        users.put("Age", age1);
                        users.put("Aboutyou", aboutyou1);
                        users.put("Gender", gender1);
                        users.put("Nationality", nationality1);
                        users.put("Car", car1);
                        users.put("CommentasPassenger", commentp);
                        users.put("CommentasDriver", commentdriver1);
                        users.put("CommentasTrip", commenttrip1);


                        documentReference.set(users).addOnSuccessListener((OnSuccessListener) (aVoid) -> {

                        });
                        if (TextUtils.isEmpty(firstname1)) {
                            firstname.setError("First name is Required");
                            return;
                        }
                        if (TextUtils.isEmpty(lastname1)) {
                            lastname.setError("Last name is Required");
                            return;
                        }
                        if (TextUtils.isEmpty(age1)) {
                            age.setError("age is Required");
                            return;
                        }
                        if (TextUtils.isEmpty(aboutyou1)) {
                            aboutyou.setError("About you is Required");

                            return;
                        }
                        if (TextUtils.isEmpty(model1)) {
                            model.setError("Model is Required");
                            return;
                        }
                        if (model1.length() < 3) {
                            model.setError("model must be >3 characters");
                            return;

                        }
                        if (TextUtils.isEmpty(color1)) {
                            color.setError("Color is Required");
                            return;
                        }

                        DocumentReference documentReference = fStore.collection("Cars").document(userID);
                        Map<String, Object> Cars = new HashMap<>();
                        Cars.put("Color", color1);
                        Cars.put("Model", model1);
                        Cars.put("Type", car1);

                        documentReference.set(Cars).addOnSuccessListener((OnSuccessListener) (aVoid) -> {
                            Toast.makeText(getApplicationContext(), "Profile updated", Toast.LENGTH_SHORT).show();
                        });

                        Intent i = new Intent(userprofile.this, openapp.class);
                        startActivity(i);

                    }
                });
            }
        });
    }

    public void deleteAccoutn_Click(View view) {
        ShowDialog();
    }
    private void ShowDialog(){
        AlertDialog.Builder builder =new AlertDialog.Builder(userprofile.this);
        builder.setTitle("Delete !");
        builder.setMessage("Are you sure to delete profile ? ");
        builder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                documentReference.delete()
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(userprofile.this,"Profile deleted !", Toast.LENGTH_SHORT);

                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(userprofile.this,"delete error !", Toast.LENGTH_SHORT);

                            }
                        });
            }
        });
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}
