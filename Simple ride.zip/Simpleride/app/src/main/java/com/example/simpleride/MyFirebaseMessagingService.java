package com.example.simpleride;

import android.widget.Toast;

import com.google.firebase.messaging.FirebaseMessagingService;

import androidx.annotation.NonNull;

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        Toast.makeText(this, "token" + token, Toast.LENGTH_LONG).show();

    }
}
