package com.example.simpleride;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;


import android.app.Activity;
import android.app.Dialog;
import android.view.Menu;



import javax.annotation.Nullable;

public class searchtrip extends AppCompatActivity {

    private DatePicker datePickert;
    private Calendar calendart;
    private TextView dateViewt;
    private int yeart, montht, dayt;

    ////
    EditText from2,to2,meetingpoint2;
    TextView Date2;
    Button time2,create2;

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String userID;

    int hour,minute;
    DatePickerDialog.OnDateSetListener  setListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searchtrip);

        dateViewt = (TextView) findViewById(R.id.tvsdate);
        calendart = Calendar.getInstance();
        yeart = calendart.get(Calendar.YEAR);

        montht = calendart.get(Calendar.MONTH);
        dayt = calendart.get(Calendar.DAY_OF_MONTH);
        showDate(yeart, montht+1, dayt);

        /////////////////
        from2=findViewById(R.id.etsfrom);
        to2=findViewById(R.id.etsto);
        meetingpoint2=findViewById(R.id.etsmeeting);
        Date2=findViewById(R.id.tvsdate);
        time2=findViewById(R.id.btstime);
        create2=findViewById(R.id.btssearch);

        fAuth=FirebaseAuth.getInstance();
        fStore=FirebaseFirestore.getInstance();

        Calendar calendar =Calendar.getInstance();
        final int year=calendar.get(Calendar.YEAR);
        final int month=calendar.get(Calendar.MONTH);
        final int day=calendar.get(Calendar.DAY_OF_MONTH);


        Places.initialize(getApplicationContext(), "AIzaSyD4S5nFUZLl4T-qQUPOzRERpY_Bf2r2ueg");
        from2.setFocusable(true);
        from2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Place.Field> fieldList = Arrays.asList(Place.Field.ADDRESS,Place.Field.LAT_LNG, Place.Field.NAME);
                Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fieldList).build(searchtrip.this);
                startActivityForResult(intent, 600);
            }
        });
        to2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Place.Field> fieldList = Arrays.asList(Place.Field.ADDRESS, Place.Field.LAT_LNG, Place.Field.NAME);
                Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY, fieldList).build(searchtrip.this);
                startActivityForResult(intent, 700);
            }
        });
        /*
        Date2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        searchtrip.this, android.R.style.Theme_Holo_Dialog_MinWidth, setListener, year, month, day);
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();


            }
        });

        setListener = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                String Date1 = day + "/" + month + "/" + year;
               // Date2.setText(Date1);
            }

        };
*/
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 600 && resultCode == RESULT_OK) {
            Place place6 = Autocomplete.getPlaceFromIntent(data);
            from2.setText(place6.getAddress());
        }
        if (requestCode == 700 && resultCode == RESULT_OK) {
            Place place7 = Autocomplete.getPlaceFromIntent(data);
            to2.setText(place7.getAddress());
        }
    }
    public void popTimePicker1(View view) {
        TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {

            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                hour = selectedHour;
                minute = selectedMinute;
                time2.setText(String.format(Locale.getDefault(), "%02d:%02d", hour, minute));
            }
        };
        TimePickerDialog timePickerDialog = new TimePickerDialog(this, onTimeSetListener, hour, minute, true);
        timePickerDialog.show();
    }
    public void onclick1(View view) {
        String sfrom = from2.getText().toString().trim();
        String sto = to2.getText().toString().trim();
        String smeetingpoint = meetingpoint2.getText().toString().trim();
        String sdate  = Date2.getText().toString().trim();
        String stime = time2.getText().toString().trim();
        if (TextUtils.isEmpty(sfrom)) {
            from2.setError("From is Required");
            return;
        }
        if (TextUtils.isEmpty(sto)) {
            to2.setError("To is Required");
            return;
        }
        if (TextUtils.isEmpty(smeetingpoint)) {
            meetingpoint2.setError("MeetingPoint is Required");
            return;
        }

        if (TextUtils.isEmpty(sdate)) {
            Date2.setError("Date is Required");
            return;
        }
        if (TextUtils.isEmpty(stime)) {
            time2.setError("Time is Required");
            return;
        }

        Toast.makeText(searchtrip.this, "Searching Trip", Toast.LENGTH_SHORT).show();
        userID = fAuth.getCurrentUser().getUid();
        DocumentReference documentReference = fStore.collection("Tripsearch").document(userID);
        Map<String, Object> Tripsearch = new HashMap<>();
        Tripsearch.put("From", sfrom);
        Tripsearch.put("To", sto);
        Tripsearch.put("Meeting point", smeetingpoint);
        Tripsearch.put("Date", sdate);
        Tripsearch.put("Time", stime);
        documentReference.set(Tripsearch).addOnSuccessListener((OnSuccessListener) (aVoid) -> {
        });

        Intent i = new Intent(searchtrip.this, tripmapsearch1.class);
        startActivity(i);
    }


    /////////////////

    @SuppressWarnings("deprecation")
    public void setDate(View view) {
        showDialog(999);
        Toast.makeText(getApplicationContext(), "ca",
                Toast.LENGTH_SHORT)
                .show();
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        // TODO Auto-generated method stub
        if (id == 999) {
            return new DatePickerDialog(this,
                    myDateListener, yeart, montht, dayt);
        }
        return null;
    }

    private DatePickerDialog.OnDateSetListener myDateListener = new
            DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker arg0,
                                      int arg1, int arg2, int arg3) {
                    // TODO Auto-generated method stub
                    // arg1 = year
                    // arg2 = month
                    // arg3 = day
                    showDate(arg1, arg2+1, arg3);
                }
            };

    private void showDate(int year, int month, int day) {
        dateViewt.setText(new StringBuilder().append(day).append("/")
                .append(month).append("/").append(year));
    }
}
