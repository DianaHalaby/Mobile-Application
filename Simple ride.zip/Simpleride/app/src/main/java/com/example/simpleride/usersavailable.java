package com.example.simpleride;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class usersavailable {
    String FirstName;
    String LastName;
    String Age;
    String Aboutyou;
// getter and setter

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        this.LastName = lastName;
    }

    public String getAge() {
        return Age;
    }

    public void setAge(String age) {
        this.Age = age;
    }

    public String getAboutyou() {
        return Aboutyou;
    }

    public void setAboutyou(String aboutyou) {
        this.Aboutyou = aboutyou;
    }

    public String getCar() {
        return Car;
    }

    public void setCar(String car) {
        this.Car = car;
    }

    public String getNationality() {
        return Nationality;
    }

    public void setNationality(String nationality) {
        this.Nationality = nationality;
    }

    public String getCommentasDriver() {
        return CommentasDriver;
    }

    public void setCommentasDriver(String commentasDriver) {
        this.CommentasDriver = commentasDriver;
    }

    public String getCommentasPassenger() {
        return CommentasPassenger;
    }

    public void setCommentasPassenger(String commentasPassenger) {
        this.CommentasPassenger = commentasPassenger;
    }

    public String getCommentasTrip() {
        return CommentasTrip;
    }

    public void setCommentasTrip(String commentasTrip) {
        this.CommentasTrip = commentasTrip;
    }

    String Car;
    String Nationality;

    public usersavailable(String lastName, String age, String aboutyou, String car, String nationality, String commentasDriver, String commentasPassenger, String commentasTrip) {
        this.LastName = lastName;
        this.Age = age;
        this.Aboutyou = aboutyou;
        this.Car = car;
        this.Nationality = nationality;
        this.CommentasDriver = commentasDriver;
        this.CommentasPassenger = commentasPassenger;
        this.CommentasTrip = commentasTrip;
    }

    String CommentasDriver;
    String CommentasPassenger;
    String CommentasTrip;
// constructor
    public usersavailable(){
        // empty constructor for firestore
        // for fiding this constructor we create my adapter2 w mn3mla extend ... mnshufa b my adapter class
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        this.FirstName = firstName;
    }

    public usersavailable(String firstName) {
        this.FirstName = firstName;
    }

}