package com.example.simpleride;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class signup extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner spinnernationality,spgender,spcar;
    EditText etemail,etpassword,etfirstname,etlastname,etage,etaboutyou;
    Button btcreataccount;
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String userID;
//for google  Twitter sign in diana
    GoogleSignInOptions gso ;
    GoogleSignInClient gsc;
    ProgressDialog progressDialog;
    ImageView googlebtn ;
    ImageView Twitterbtn ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        //added new just diana

        //for google
        googlebtn=findViewById(R.id.googlebtn);
        gso=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail().build();
        gsc= GoogleSignIn.getClient(this , gso);
        //Twitter
        Twitterbtn=findViewById(R.id.twitterbtn);
        //
        fAuth=FirebaseAuth.getInstance();
        fStore=FirebaseFirestore.getInstance();

        spinnernationality = findViewById(R.id.spnationality);
        btcreataccount = findViewById(R.id.btcreateaccount);
        etaboutyou=findViewById(R.id.etaboutyousignup);
        etemail = findViewById(R.id.etloginemail);
        etpassword = findViewById(R.id.etloginpassword);
        etfirstname = findViewById(R.id.etfirstname);
        etlastname = findViewById(R.id.etlastname);
        etage = findViewById(R.id.etage);
        spgender = findViewById(R.id.spgender);
        spcar = findViewById(R.id.spcar);

        int pos = 0; //position
        spinnernationality.setSelection(pos);
        spgender.setSelection(pos);
        spcar.setSelection(pos);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Nationalities, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnernationality.setAdapter(adapter);
        spinnernationality.setOnItemSelectedListener(this); //3ata error

        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.Gender, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spgender.setAdapter(adapter1);
        spgender.setOnItemSelectedListener(this);//error

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.CarType, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spcar.setAdapter(adapter2);
        spcar.setOnItemSelectedListener(this);//error

        btcreataccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = etemail.getText().toString().trim();
                String password = etpassword.getText().toString().trim();
                String firstname = etfirstname.getText().toString().trim();
                String lastname = etlastname.getText().toString().trim();
                String age = etage.getText().toString().trim();
                String nationality = spinnernationality.getSelectedItem().toString().trim();
                String gender = spgender.getSelectedItem().toString().trim();
                String car = spcar.getSelectedItem().toString().trim();
                String aboutyou=etaboutyou.getText().toString().trim();


                if (TextUtils.isEmpty(email)) {
                    etemail.setError("Email is Required");
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    etpassword.setError("Password is Required");
                    return;
                }
                if (TextUtils.isEmpty(firstname)) {
                    etfirstname.setError("First name is Required");
                    return;
                }
                if (TextUtils.isEmpty(lastname)) {
                    etlastname.setError("Last name is Required");
                    return;
                }
                if (TextUtils.isEmpty(age)) {
                    etage.setError("age is Required");
                    return;
                }
                if (TextUtils.isEmpty(age)) {
                    etage.setError("age is Required");
                    return;
                }

                if (password.length() < 6) {
                    etpassword.setError("Password must be >=8 characters");
                    return;
                } if (TextUtils.isEmpty(aboutyou)) {
                    etaboutyou.setError("About you is Required");

                    return;
                }if (aboutyou.length() < 8) {
                    etaboutyou.setError("About you must be >=8 characters");
                    return;
                }

                fAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(task ->  {
                    if (task.isSuccessful()) {
                        Toast.makeText(signup.this, "User Created", Toast.LENGTH_SHORT).show();

                        userID=fAuth.getCurrentUser().getUid();

                        DocumentReference documentReference=fStore.collection("users").document(userID);
                        Map<String,Object> users=new HashMap<>();
                        users.put("email",email);
                        users.put("FirstName",firstname);
                        users.put("LastName",lastname);
                        users.put("Age",age);
                        users.put("Nationality",nationality);
                        users.put("Gender",gender);
                        users.put("Car",car);
                        users.put("Aboutyou",aboutyou);

                        documentReference.set(users).addOnSuccessListener((OnSuccessListener) (aVoid) ->{

                            Toast.makeText(signup.this, "User profile created for user ID "+userID, Toast.LENGTH_SHORT).show();

                        });

                        Intent i = new Intent(signup.this, userprofile.class);
                        startActivity(i);
                    } else {
                        Toast.makeText(signup.this, "Error", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

//tsli7 lerror
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(position >= 0){
            String text=parent.getItemAtPosition(position).toString();
            Toast.makeText(parent.getContext(),text,Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }


// added new
    //google login
    public void Googlebtn_Click(View view) {
    progressDialog=new ProgressDialog(this);
    progressDialog.setMessage("Google Sign In...");
    progressDialog.show();
    SignIn();
    }

    private void SignIn() {
        Intent intent =gsc.getSignInIntent();
        startActivityForResult(intent, 100);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==100){
            Task<GoogleSignInAccount> task =GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                task.getResult(ApiException.class);
                HomeActivity();

            } catch (ApiException e) {
                Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
            }

        }
    }

    private void HomeActivity() {
        finish();
        Intent intent=new Intent(getApplicationContext(),SecondActivity.class);
        startActivity(intent);
    }

    //Twitter sign in
    public void Twitter_Click(View view) {
        Intent intent =new Intent(signup.this ,TwitterActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
    }

}
