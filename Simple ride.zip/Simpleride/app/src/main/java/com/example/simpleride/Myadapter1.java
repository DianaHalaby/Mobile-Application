package com.example.simpleride;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class Myadapter1 extends RecyclerView.Adapter<Myadapter1.MyViewHolders> {

    Context context1;
    ArrayList<tripsavailable> tripsavailableArrayList;
    public Myadapter1(Context context1, ArrayList<tripsavailable> tripsavailableArrayList) {
        this.context1 = context1;
        this.tripsavailableArrayList = tripsavailableArrayList;
    }


    @NonNull
    @Override
    public Myadapter1.MyViewHolders onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View c= LayoutInflater.from(context1).inflate(R.layout.item1,parent,false);
        return new MyViewHolders(c);
    }

    @Override
    public void onBindViewHolder(@NonNull Myadapter1.MyViewHolders holder, int position) {
        tripsavailable tripsavailable1=tripsavailableArrayList.get(position);
        holder.tacolor.setText(tripsavailable1.CarColor);
        holder.tafname1.setText(tripsavailable1.FirstName);
        holder.tasstop.setText(tripsavailable1.SecondStop);
        holder.tafstop.setText(tripsavailable1.FirstStop);
        holder.tafrom.setText(tripsavailable1.From);
        holder.tato.setText(tripsavailable1.To);
        holder.tatime.setText(tripsavailable1.Time);
        holder.tacar.setText(tripsavailable1.CarType);
        holder.tripownertoken.setText(tripsavailable1.TripOwnerToken);
        holder.tripsavailable1=tripsavailable1;
        holder.tuserid1.setText(tripsavailable1.TUserId);

    }

    @Override
    public int getItemCount() {
        return tripsavailableArrayList.size();
    }

    public  static  class MyViewHolders extends RecyclerView.ViewHolder {

        TextView tafname1,tafrom,tato,tafstop,tasstop,tatime,tacolor,tacar,tripownertoken,tuserid1;
        Button jointrip;
        tripsavailable tripsavailable1;

        public MyViewHolders(@NonNull View itemView) {
            super(itemView);

            tafname1=itemView.findViewById(R.id.taname);
            tafrom=itemView.findViewById(R.id.tafrom);
            tato=itemView.findViewById(R.id.tato);
            tatime=itemView.findViewById(R.id.tatime);
            tafstop=itemView.findViewById(R.id.tafstop);
            tasstop=itemView.findViewById(R.id.tasstop);
            tacar=itemView.findViewById(R.id.tacar);
            tacolor=itemView.findViewById(R.id.tacolor);
            tripownertoken=itemView.findViewById(R.id.tripownertokenet);
            tuserid1=itemView.findViewById(R.id.tuserid1);
            jointrip=itemView.findViewById(R.id.btjoin);

            jointrip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View C) {

                    Intent t= new Intent(C.getContext(), messageowner.class);

                    String tuserid=tuserid1.getText().toString();
                    t.putExtra("tuserid",tuserid);
                    String ttoken = tripownertoken.getText().toString();
                    t.putExtra("totokenkey", ttoken);
                    C.getContext().startActivity(t);
                    Toast.makeText(C.getContext(), "Joining! " + tripsavailable1.FirstName, Toast.LENGTH_SHORT).show();

                }
            });

        }
    }
}

