package com.example.simpleride;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class rateus extends AppCompatActivity {

    Button rateu,btmainu;
    EditText commentu;

    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rateus);

        rateu=findViewById(R.id.btrateu);
        btmainu=findViewById(R.id.btmain);
        commentu=findViewById(R.id.etcommetus);

        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        userID = fAuth.getCurrentUser().getUid();


        rateu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String commentu1=commentu.getText().toString().trim();
                userID=fAuth.getCurrentUser().getUid();

                DocumentReference documentReference35=fStore.collection("CommentsAboutUs").document(userID);

                Map<String,Object> CommentsAboutUs=new HashMap<>();
                CommentsAboutUs.put("Comments",commentu1);
                CommentsAboutUs.put("UserId",userID);

                documentReference35.set(CommentsAboutUs).addOnSuccessListener((OnSuccessListener) (aVoid) ->{
                    Toast. makeText(getApplicationContext(),"Thanks For your Comment!",Toast. LENGTH_SHORT).show();

                });
            }
        });
        btmainu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(rateus.this, openapp.class);
                startActivity(i);
                Toast. makeText(getApplicationContext(),"Back To Main",Toast. LENGTH_SHORT).show();

            }
        });
    }
}