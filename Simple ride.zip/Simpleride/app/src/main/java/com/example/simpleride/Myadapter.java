package com.example.simpleride;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class Myadapter extends RecyclerView.Adapter<Myadapter.MyViewHolder> {
    Context context ;
    ArrayList<passengeravailable> passengeravailableArrayList;

    public Myadapter(Context context , ArrayList<passengeravailable> passengeravailableArrayList) {
        this.context = context;
        this.passengeravailableArrayList = passengeravailableArrayList;
    }

    @NonNull
    @Override
    public Myadapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(context).inflate(R.layout.item,parent, false);
        return  new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Myadapter.MyViewHolder holder, int position) {
        passengeravailable passengeravailable1=passengeravailableArrayList.get(position);
        holder.pfrom.setText(passengeravailable1.From);
        holder.pto.setText(passengeravailable1.To);
        holder.pmp.setText(passengeravailable1.Meetingpoint);
        holder.ptime.setText(passengeravailable1.Time);
        holder.pname.setText(passengeravailable1.FirstName);
        holder.spassengertoken.setText(passengeravailable1.PassengerToken);
        holder.tvpuserid.setText(passengeravailable1.PuserId);


        holder.passengeravailable1=passengeravailable1;

    }

    @Override
    public int getItemCount() {
        return passengeravailableArrayList.size();

    }
    public  static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView pfrom,pto,ptime,pmp,pname,spassengertoken,tvpuserid;
        Button pick;
        passengeravailable passengeravailable1;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            pfrom=itemView.findViewById(R.id.textView12);
            pto=itemView.findViewById(R.id.textView13);
            pname=itemView.findViewById(R.id.textView15);
            pmp=itemView.findViewById(R.id.textView14);
            ptime=itemView.findViewById(R.id.textView11);
            pick=itemView.findViewById(R.id.btpick);
            tvpuserid=itemView.findViewById(R.id.tvuserid);
            spassengertoken=itemView.findViewById(R.id.searchpassengertoken);

            pick.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent i = new Intent(v.getContext(), testmassege.class);
                    String pid = tvpuserid.getText().toString();
                    i.putExtra("pidkey", pid);

                    String ptoken = spassengertoken.getText().toString();
                    i.putExtra("tokenkey", ptoken);
                    v.getContext().startActivity(i);
                    Toast.makeText(v.getContext(), "Picking up! " + passengeravailable1.FirstName, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
