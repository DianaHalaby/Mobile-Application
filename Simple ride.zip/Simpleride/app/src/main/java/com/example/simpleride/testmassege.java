package com.example.simpleride;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.messaging.FirebaseMessaging;

public class testmassege extends AppCompatActivity {

    EditText title,type ,tokenuser ,useridd ;
    Button senduser,rate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testmassege);

        title=findViewById(R.id.ettitle);
        type=findViewById(R.id.ettype);
        useridd=findViewById(R.id.etpuserdd);

        rate=findViewById(R.id.btrate);
        tokenuser=findViewById(R.id.ettokenuser);
        senduser=findViewById(R.id.btsenduser);

     //for sending notification to all
        FirebaseMessaging.getInstance().subscribeToTopic("all");
        Intent i = getIntent();
        String pid=i.getStringExtra("pidkey");
        useridd.setText(pid);
        String ptoken = i.getStringExtra("tokenkey");
        tokenuser.setText(ptoken);


        senduser.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                if(!title.getText().toString().isEmpty() && !type.getText().toString().isEmpty() && !tokenuser.getText().toString().isEmpty()) {
                    FcmNotificationsSender fcmNotificationsSender = new FcmNotificationsSender(tokenuser.getText().toString(),
                            title.getText().toString(), type.getText().toString(),getApplicationContext(), testmassege.this);
                    fcmNotificationsSender.SendNotifications();
                    Toast.makeText(testmassege.this, "Sending Message", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(testmassege.this, "Please Fill al details!!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        rate.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
          Intent u=new Intent(testmassege.this,Ratepassenger.class);
          String pidr = useridd.getText().toString();
          u.putExtra("pidrkey", pidr);
          Toast.makeText(testmassege.this,"opening",Toast.LENGTH_SHORT).show();
          startActivity(u);
         }
        }
        );
    }
}