package com.example.simpleride;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.Toast;

import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class allusers extends AppCompatActivity  {
//klshi st5dmto 3rftoo honn
    RecyclerView urc;
    ArrayList<usersavailable> usersavailableArrayList;
    Myadapter2 myadapter2;
    //law ma st5dmna lprogress diagram ra7 ytawel w yle2i mtl page bayda ma bel ma jbna lma3lumet .
    ProgressDialog progressDialog;

    FirebaseFirestore fStore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allusers);

        fStore = FirebaseFirestore.getInstance();

        progressDialog=new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Fetching Data");
        progressDialog.show();

        urc=findViewById(R.id.urc);
        urc.setHasFixedSize(true);
        urc.setLayoutManager(new LinearLayoutManager(this));

        usersavailableArrayList=new ArrayList<usersavailable>();
        myadapter2=new Myadapter2(allusers.this,usersavailableArrayList);
        urc.setAdapter(myadapter2);

        Toast.makeText(allusers.this,"You Should Save your Profile To Update Your Infos",Toast.LENGTH_LONG).show();
        EventChangeListener();//bs 3mlna he mn3mla create bytl3la lprivate void
    }

    private void EventChangeListener() {
        fStore.collection("users").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if (error!=null){
                    if(progressDialog.isShowing())
                        progressDialog.dismiss(); //3mlna dissmiss ma bytl3 page fadiye awl shii
                    Toast.makeText(allusers.this,"Firestore Error",Toast.LENGTH_SHORT).show();
                }
                for (DocumentChange dc:value.getDocumentChanges()) {
                    if (dc.getType() == DocumentChange.Type.ADDED) {
                        usersavailableArrayList.add(dc.getDocument().toObject(usersavailable.class));
                    }
                    myadapter2.notifyDataSetChanged(); // hk mnkun jbna jkl ldataa mn lfirestore w mnkun htaynehun bl user ....
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }
                for (DocumentChange dc1:value.getDocumentChanges()) {
                    if (dc1.getType() == DocumentChange.Type.MODIFIED) {
                        usersavailableArrayList.add(dc1.getDocument().toObject(usersavailable.class));
                    }
                    myadapter2.notifyDataSetChanged();
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }
                for (DocumentChange dc2:value.getDocumentChanges()) {
                    if (dc2.getType() == DocumentChange.Type.REMOVED) {
                        usersavailableArrayList.add(dc2.getDocument().toObject(usersavailable.class));
                    }
                    myadapter2.notifyDataSetChanged();
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                }
            }
        });
    }
}
