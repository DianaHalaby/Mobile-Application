package com.example.simpleride;

public class tripsavailable {

    String FirstName;
    String From;
    String To;
    String FirstStop;
    String SecondStop;
    String CarColor;
    String CarType;
    String Time;
    String TripOwnerToken;
    String TUserId;

    public tripsavailable(String tripOwnerToken) {
        TripOwnerToken = tripOwnerToken;
    }

    public String getTripOwnerToken() {
        return TripOwnerToken;
    }

    public void setTripOwnerToken(String tripOwnerToken) {
        this.TripOwnerToken = tripOwnerToken;
    }

    public String getTUserId() {
        return TUserId;
    }

    public void setTUserId(String TUserId) {
        this.TUserId = TUserId;

    }

    public tripsavailable(){}

    public tripsavailable(String firstname, String from, String to, String firstStop, String secondStop, String carColor, String carType, String time) {
        this.FirstName = firstname;
        this.From = from;
        this.To = to;
        this.FirstStop = firstStop;
        this.SecondStop = secondStop;
        this.CarColor = carColor;
        this.CarType = carType;
        this.Time = time;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }



    public String getFrom() {
        return From;
    }

    public void setFrom(String from) {
        this.From = from;
    }

    public String getTo() {
        return To;
    }

    public void setTo(String to) {
        this.To = to;
    }

    public String getFirstStop() {
        return FirstStop;
    }

    public void setFirstStop(String firstStop) {
        this.FirstStop = firstStop;
    }

    public String getSecondStop() {
        return SecondStop;
    }

    public void setSecondStop(String secondStop) {
        this.SecondStop = secondStop;
    }

    public String getCarColor() {
        return CarColor;
    }

    public void setCarColor(String carColor) {
        this.CarColor = carColor;
    }

    public String getCarType() {
        return CarType;
    }

    public void setCarType(String carType) {
        this.CarType = carType;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        this.Time = time;
    }
}
